from flask import Flask, render_template, request, redirect, url_for, flash, session
import psycopg2
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Konfigurasi koneksi database PostgreSQL
conn = psycopg2.connect(
    host="localhost",
    database="artivo",
    user="postgres",
    password="daniel",
    port="5432"
)

def execute_query(query, data=None, fetchall=False):
    cursor = conn.cursor()
    cursor.execute(query, data)
    conn.commit()
    if fetchall:
        result = cursor.fetchall()
    else:
        result = cursor.fetchone()
    cursor.close()
    return result



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    cursor = conn.cursor()  # Mendapatkan kursor dari koneksi

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Query untuk mencari pengguna berdasarkan username
        query = "SELECT * FROM users WHERE username = %s"
        cursor.execute(query, (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user[2], password):  # user[2] adalah kolom password_hash di tabel
            session['user_id'] = user[0]  # Menyimpan user_id dalam session
            flash('Login berhasil!', 'success')
            cursor.close()  # Menutup kursor setelah digunakan
            return redirect(url_for('view_recipes'))
        else:
            flash('Login gagal. Periksa kembali username dan password Anda.', 'danger')

    cursor.close()  # Menutup kursor jika tidak ada data yang ditemukan
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)  # Menghapus user_id dari session
    flash('Anda telah keluar.', 'info')
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Periksa apakah username sudah digunakan
        query = "SELECT * FROM users WHERE username = %s"
        execute_query(query, (username,))
        existing_user = cursor.fetchone()

        if existing_user:
            flash('Username sudah digunakan. Pilih yang lain.', 'danger')
        else:
            # Tambahkan pengguna baru ke database
            password_hash = generate_password_hash(password)
            insert_query = "INSERT INTO users (username, password_hash) VALUES (%s, %s)"
            execute_query(insert_query, (username, password_hash))
            flash('Pendaftaran berhasil! Silakan login.', 'success')
            return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/view_recipes')
def view_recipes():
    recipes = execute_query("SELECT * FROM recipes", fetchall=True)
    recipe_comments = {}
 
    for recipe in recipes:
        recipe_id = recipe[0]
        comments = execute_query("SELECT text FROM comments WHERE recipe_id = %s", (recipe_id,), fetchall=True)
        recipe_comments[recipe_id] = comments
 
    return render_template('view_recipes.html', recipes=recipes, recipe_comments=recipe_comments)




@app.route('/create_recipe', methods=['GET', 'POST'])
def create_recipe():
    if 'user_id' not in session:
        flash('Anda harus login terlebih dahulu.', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        ingredients = request.form['ingredients']
        instructions = request.form['instructions']
        user_id = session['user_id']

        execute_query("INSERT INTO recipes (title, ingredients, instructions, user_id) VALUES (%s, %s, %s, %s)",
                      (title, ingredients, instructions, user_id))
        flash('Resep berhasil dibuat!', 'success')
        return redirect(url_for('view_recipes'))

    return render_template('create_recipe.html')

if __name__ == '__main__':
    app.run(debug=True)
